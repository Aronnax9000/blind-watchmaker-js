
function TriangleMenuHandler() {
}

TriangleMenuHandler.prototype.menuclick = function(event) {
    let target = event.target
    let menuid = $(target).data('menuid')
    switch(menuid) {
        default:
    }
    return true;
}

